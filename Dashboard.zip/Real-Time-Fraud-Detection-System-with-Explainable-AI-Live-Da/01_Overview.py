"""
Page 1 — Overview
KPI cards + interactive Plotly charts with sidebar filters.
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from data_utils import load_data

# ── Load ──────────────────────────────────────────────────────────────────────
@st.cache_data(show_spinner="Loading transactions…")
def get_data():
    return load_data()

df = get_data()

# ── Sidebar filters ───────────────────────────────────────────────────────────
st.sidebar.header("🎛️ Filters")

products = st.sidebar.multiselect(
    "Product Code", options=sorted(df["ProductCD"].unique()),
    default=sorted(df["ProductCD"].unique())
)
cards = st.sidebar.multiselect(
    "Card Type", options=sorted(df["card4"].unique()),
    default=sorted(df["card4"].unique())
)
devices = st.sidebar.multiselect(
    "Device Type", options=sorted(df["DeviceType"].unique()),
    default=sorted(df["DeviceType"].unique())
)
amt_range = st.sidebar.slider(
    "Transaction Amount ($)", float(df["TransactionAmt"].min()),
    float(df["TransactionAmt"].max()),
    (float(df["TransactionAmt"].min()), float(df["TransactionAmt"].max())),
    step=10.0
)

mask = (
    df["ProductCD"].isin(products) &
    df["card4"].isin(cards) &
    df["DeviceType"].isin(devices) &
    df["TransactionAmt"].between(*amt_range)
)
fdf = df[mask]

# ── Page header ───────────────────────────────────────────────────────────────
st.title("📊 Overview")
st.caption(f"Showing **{len(fdf):,}** of {len(df):,} transactions after filters")

# ── KPI cards ─────────────────────────────────────────────────────────────────
total_txns   = len(fdf)
total_fraud  = fdf["isFraud"].sum()
det_rate     = total_fraud / total_txns * 100 if total_txns else 0
avg_fraud_amt = fdf.loc[fdf["isFraud"] == 1, "TransactionAmt"].mean() if total_fraud else 0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Transactions",  f"{total_txns:,}")
k2.metric("Total Fraud Cases",   f"{int(total_fraud):,}",
          delta=f"{det_rate:.2f}% of total", delta_color="inverse")
k3.metric("Detection Rate",      f"{det_rate:.2f}%")
k4.metric("Avg Fraud Amount",    f"${avg_fraud_amt:,.2f}")

st.divider()

# ── Charts ────────────────────────────────────────────────────────────────────
col1, col2 = st.columns(2)

with col1:
    st.subheader("Fraud vs Legitimate by Product")
    prod_cnt = (
        fdf.groupby(["ProductCD", "isFraud"])
           .size().reset_index(name="count")
    )
    prod_cnt["label"] = prod_cnt["isFraud"].map({0: "Legitimate", 1: "Fraud"})
    fig = px.bar(
        prod_cnt, x="ProductCD", y="count", color="label",
        barmode="group",
        color_discrete_map={"Legitimate": "#3b82f6", "Fraud": "#ef4444"},
        template="plotly_white"
    )
    fig.update_layout(legend_title_text="", height=350)
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Transaction Amount Distribution")
    fig2 = px.histogram(
        fdf, x="TransactionAmt",
        color=fdf["isFraud"].map({0: "Legitimate", 1: "Fraud"}),
        nbins=60, barmode="overlay", opacity=0.7,
        color_discrete_map={"Legitimate": "#3b82f6", "Fraud": "#ef4444"},
        template="plotly_white"
    )
    fig2.update_layout(legend_title_text="", height=350,
                       xaxis_title="Amount ($)", yaxis_title="Count")
    st.plotly_chart(fig2, use_container_width=True)

col3, col4 = st.columns(2)

with col3:
    st.subheader("Fraud by Hour of Day")
    hourly = (
        fdf[fdf["isFraud"] == 1]
           .groupby("hour").size().reset_index(name="fraud_count")
    )
    fig3 = px.area(
        hourly, x="hour", y="fraud_count",
        color_discrete_sequence=["#ef4444"],
        template="plotly_white"
    )
    fig3.update_layout(height=300, xaxis_title="Hour", yaxis_title="Fraud Count")
    st.plotly_chart(fig3, use_container_width=True)

with col4:
    st.subheader("Risk Score Distribution")
    fig4 = go.Figure()
    fig4.add_trace(go.Violin(
        y=fdf.loc[fdf["isFraud"] == 0, "risk_score"],
        name="Legitimate", side="negative",
        line_color="#3b82f6", fillcolor="#bfdbfe", opacity=0.7
    ))
    fig4.add_trace(go.Violin(
        y=fdf.loc[fdf["isFraud"] == 1, "risk_score"],
        name="Fraud", side="positive",
        line_color="#ef4444", fillcolor="#fecaca", opacity=0.7
    ))
    fig4.update_layout(
        template="plotly_white", height=300,
        violingap=0, violinmode="overlay",
        yaxis_title="Risk Score"
    )
    st.plotly_chart(fig4, use_container_width=True)

# ── Fraud by card type (full-width) ──────────────────────────────────────────
st.subheader("Fraud Rate by Card Network")
card_stats = (
    fdf.groupby("card4")
       .agg(total=("isFraud", "count"), fraud=("isFraud", "sum"))
       .reset_index()
)
card_stats["fraud_rate"] = (card_stats["fraud"] / card_stats["total"] * 100).round(2)

fig5 = px.bar(
    card_stats.sort_values("fraud_rate", ascending=False),
    x="card4", y="fraud_rate",
    text="fraud_rate",
    color="fraud_rate",
    color_continuous_scale=["#bbf7d0", "#fde68a", "#fca5a5", "#ef4444"],
    template="plotly_white", height=320
)
fig5.update_traces(texttemplate="%{text:.2f}%", textposition="outside")
fig5.update_layout(coloraxis_showscale=False, xaxis_title="Card Network",
                   yaxis_title="Fraud Rate (%)")
st.plotly_chart(fig5, use_container_width=True)
