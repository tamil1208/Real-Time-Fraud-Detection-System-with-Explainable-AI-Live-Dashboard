"""
Page 4 — Visualizations
5 required charts + bonus interactive scatter.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import json, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from data_utils import load_data, FEATURES

@st.cache_data(show_spinner="Loading data…")
def get_data():
    return load_data()

@st.cache_data(show_spinner="Loading pre-computed visualisation data…")
def get_viz():
    p = os.path.join(os.path.dirname(os.path.dirname(__file__)), ".cache", "viz_data.json")
    if not os.path.exists(p):
        st.error("viz_data.json missing — run: python -c 'from pages.04_Visualizations import *'")
        st.stop()
    with open(p) as f:
        return json.load(f)

df  = get_data()
viz = get_viz()

# ── Sidebar ───────────────────────────────────────────────────────────────────
st.sidebar.header("🎛️ Filters")
products = st.sidebar.multiselect(
    "Product Code", sorted(df["ProductCD"].unique()),
    default=sorted(df["ProductCD"].unique()), key="v_prod"
)
devices = st.sidebar.multiselect(
    "Device Type", sorted(df["DeviceType"].unique()),
    default=sorted(df["DeviceType"].unique()), key="v_dev"
)
amt_max = st.sidebar.slider("Max Transaction Amount ($)", 100, int(df["TransactionAmt"].max()),
                             int(df["TransactionAmt"].max()), step=100, key="v_amt")
fdf = df[
    df["ProductCD"].isin(products) &
    df["DeviceType"].isin(devices) &
    (df["TransactionAmt"] <= amt_max)
]

# ── Page header ───────────────────────────────────────────────────────────────
st.title("📈 Visualizations")
st.caption("5 core ML/fraud charts + 1 interactive bonus. All charts respond to sidebar filters where applicable.")

COLORS = {
    "fraud":  "#ef4444",
    "legit":  "#3b82f6",
    "accent": "#8b5cf6",
    "mid":    "#f59e0b",
    "ok":     "#22c55e",
}

# ════════════════════════════════════════════════════════════════════════════════
# CHART 1 — SHAP Global Summary
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("1 · SHAP Global Feature Importance")
st.caption("Mean |SHAP value| across 500 sampled transactions — higher = stronger influence on fraud prediction.")

mean_abs   = np.array(viz["mean_abs"])
feat_lbls  = viz["feat_labels"]
order      = np.argsort(mean_abs)          # ascending for horizontal bar
sv_all     = np.array(viz["shap_vals"])    # (500, 9)
y_sample   = np.array(viz["y_sample"])

c1, c2 = st.columns([1, 1])

with c1:
    # Mean |SHAP| bar
    fig = go.Figure(go.Bar(
        x=mean_abs[order],
        y=[feat_lbls[i] for i in order],
        orientation="h",
        marker=dict(
            color=mean_abs[order],
            colorscale=[[0, "#bfdbfe"], [0.5, "#8b5cf6"], [1, "#ef4444"]],
            showscale=True,
            colorbar=dict(title="Mean |SHAP|", thickness=12, len=0.8)
        ),
        text=[f"{v:.3f}" for v in mean_abs[order]],
        textposition="outside",
    ))
    fig.update_layout(
        template="plotly_white", height=360,
        xaxis_title="Mean |SHAP value|",
        margin=dict(l=10, r=80, t=10, b=40),
        showlegend=False,
    )
    st.plotly_chart(fig, use_container_width=True)

with c2:
    # SHAP beeswarm proxy — violin per feature (top 5)
    top5 = np.argsort(mean_abs)[::-1][:5]
    fig2 = go.Figure()
    palette = ["#ef4444", "#f59e0b", "#8b5cf6", "#3b82f6", "#22c55e"]
    for idx, (fi, col) in enumerate(zip(top5, palette)):
        fig2.add_trace(go.Violin(
            y=sv_all[:, fi],
            name=feat_lbls[fi],
            side="positive",
            meanline_visible=True,
            line_color=col,
            fillcolor=col + "44",
            opacity=0.8,
            width=0.8,
            points=False,
        ))
    fig2.update_layout(
        template="plotly_white", height=360,
        yaxis_title="SHAP value",
        showlegend=False,
        margin=dict(l=10, r=10, t=10, b=80),
        xaxis_tickangle=-30,
        violinmode="overlay",
    )
    st.plotly_chart(fig2, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════════
# CHART 2 — Fraud Rate by Hour of Day
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("2 · Fraud Rate by Hour of Day")
st.caption("Proportion of transactions flagged as fraud for each hour, with transaction volume in background.")

hourly = (
    fdf.groupby("hour")
       .agg(total=("isFraud", "count"), fraud=("isFraud", "sum"))
       .reset_index()
)
hourly["rate"] = hourly["fraud"] / hourly["total"] * 100

fig3 = make_subplots(specs=[[{"secondary_y": True}]])
fig3.add_trace(go.Bar(
    x=hourly["hour"], y=hourly["total"],
    name="Transaction Volume",
    marker_color="#bfdbfe",
    opacity=0.6,
), secondary_y=True)
fig3.add_trace(go.Scatter(
    x=hourly["hour"], y=hourly["rate"],
    mode="lines+markers",
    name="Fraud Rate %",
    line=dict(color=COLORS["fraud"], width=2.5),
    marker=dict(size=7, color=COLORS["fraud"]),
    fill="tozeroy",
    fillcolor="rgba(239,68,68,0.12)",
), secondary_y=False)

# Annotate peak hour
peak_h = hourly.loc[hourly["rate"].idxmax()]
fig3.add_annotation(
    x=peak_h["hour"], y=peak_h["rate"],
    text=f"Peak {peak_h['rate']:.1f}%",
    showarrow=True, arrowhead=2, arrowcolor=COLORS["fraud"],
    bgcolor="white", bordercolor=COLORS["fraud"], borderwidth=1,
    font=dict(color=COLORS["fraud"], size=12),
    secondary_y=False,
)
fig3.update_layout(
    template="plotly_white", height=380,
    legend=dict(orientation="h", y=1.08),
    margin=dict(t=20, b=40),
)
fig3.update_yaxes(title_text="Fraud Rate (%)", secondary_y=False)
fig3.update_yaxes(title_text="Transaction Count", secondary_y=True, showgrid=False)
fig3.update_xaxes(title_text="Hour of Day", tickvals=list(range(0, 24, 2)))
st.plotly_chart(fig3, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════════
# CHART 3 — Transaction Amount Distribution
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("3 · Transaction Amount Distribution")
st.caption("Log-scale histogram comparing legitimate vs fraud transaction amounts.")

c3, c4 = st.columns([2, 1])

with c3:
    fig4 = go.Figure()
    for label, mask, color in [
        ("Legitimate", fdf["isFraud"] == 0, COLORS["legit"]),
        ("Fraud",      fdf["isFraud"] == 1, COLORS["fraud"]),
    ]:
        vals = fdf.loc[mask, "TransactionAmt"]
        fig4.add_trace(go.Histogram(
            x=vals,
            name=label,
            nbinsx=60,
            marker_color=color,
            opacity=0.7,
            histnorm="probability density",
        ))
    fig4.update_layout(
        barmode="overlay",
        template="plotly_white",
        height=340,
        xaxis_title="Transaction Amount ($)",
        yaxis_title="Density",
        legend=dict(orientation="h", y=1.08),
        margin=dict(t=20, b=40),
        xaxis=dict(type="log"),
    )
    fig4.add_vline(
        x=fdf.loc[fdf["isFraud"]==1, "TransactionAmt"].median(),
        line_dash="dash", line_color=COLORS["fraud"],
        annotation_text=f"Fraud median ${fdf.loc[fdf['isFraud']==1,'TransactionAmt'].median():,.0f}",
        annotation_position="top right",
    )
    st.plotly_chart(fig4, use_container_width=True)

with c4:
    # Box plot
    fig5 = go.Figure()
    for label, mask, color in [
        ("Legitimate", fdf["isFraud"] == 0, COLORS["legit"]),
        ("Fraud",      fdf["isFraud"] == 1, COLORS["fraud"]),
    ]:
        fig5.add_trace(go.Box(
            y=fdf.loc[mask, "TransactionAmt"],
            name=label,
            marker_color=color,
            boxmean="sd",
            whiskerwidth=0.5,
        ))
    fig5.update_layout(
        template="plotly_white", height=340,
        yaxis_title="Amount ($)", yaxis_type="log",
        showlegend=False,
        margin=dict(t=20, b=40),
    )
    st.plotly_chart(fig5, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════════
# CHART 4 — Risk Tier Donut
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("4 · Risk Tier Breakdown")
st.caption("Transactions bucketed into Low / Medium / High risk tiers based on model probability score.")

def tier(s):
    if s >= 0.7: return "High Risk"
    if s >= 0.4: return "Medium Risk"
    return "Low Risk"

fdf2 = fdf.copy()
fdf2["tier"] = fdf2["risk_score"].apply(tier)
tier_counts = fdf2["tier"].value_counts()

tier_colors = {"Low Risk": COLORS["ok"], "Medium Risk": COLORS["mid"], "High Risk": COLORS["fraud"]}
tiers_ordered = ["High Risk", "Medium Risk", "Low Risk"]

c5, c6 = st.columns([1, 1])

with c5:
    fig6 = go.Figure(go.Pie(
        labels=[t for t in tiers_ordered if t in tier_counts],
        values=[tier_counts.get(t, 0) for t in tiers_ordered if t in tier_counts],
        hole=0.62,
        marker=dict(colors=[tier_colors[t] for t in tiers_ordered if t in tier_counts],
                    line=dict(color="white", width=3)),
        textinfo="label+percent",
        textfont=dict(size=13),
        direction="clockwise",
        sort=False,
    ))
    total = len(fdf2)
    fig6.update_layout(
        template="plotly_white", height=320,
        annotations=[dict(text=f"<b>{total:,}</b><br>transactions",
                          x=0.5, y=0.5, font_size=15, showarrow=False)],
        showlegend=False,
        margin=dict(t=10, b=10, l=10, r=10),
    )
    st.plotly_chart(fig6, use_container_width=True)

with c6:
    # Tier metrics + stacked bar by product
    for t in tiers_ordered:
        n   = tier_counts.get(t, 0)
        pct = n / total * 100
        col = tier_colors[t]
        st.markdown(
            f"<div style='display:flex;align-items:center;gap:12px;margin:8px 0'>"
            f"<span style='width:14px;height:14px;border-radius:3px;background:{col};flex-shrink:0'></span>"
            f"<span style='flex:1;font-size:14px'>{t}</span>"
            f"<span style='font-weight:600;font-size:15px'>{n:,}</span>"
            f"<span style='color:#888;font-size:13px'>({pct:.1f}%)</span>"
            f"</div>",
            unsafe_allow_html=True,
        )
    st.caption("")
    # Fraud in each tier
    tier_fraud = fdf2.groupby("tier")["isFraud"].mean() * 100
    for t in tiers_ordered:
        rate = tier_fraud.get(t, 0)
        st.metric(f"Fraud within {t}", f"{rate:.1f}%")

# ════════════════════════════════════════════════════════════════════════════════
# CHART 5 — Precision-Recall Curve with Optimal Threshold
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("5 · Precision-Recall Curve & Optimal Threshold")
st.caption(f"Average Precision = **{viz['ap']:.4f}**. Optimal threshold found at **{viz['opt_thresh']:.4f}** (max F1).")

prec_arr   = np.array(viz["prec"])
rec_arr    = np.array(viz["rec"])
threshs_arr = np.array(viz["threshs"])
opt_thresh = viz["opt_thresh"]
opt_prec   = viz["opt_prec"]
opt_rec    = viz["opt_rec"]
opt_f1     = viz["opt_f1"]

# Subsample for chart (5001 points is fine but let's keep it)
step = max(1, len(prec_arr) // 500)
p_s = prec_arr[::step]
r_s = rec_arr[::step]

fig7 = go.Figure()
# Fill under curve
fig7.add_trace(go.Scatter(
    x=r_s, y=p_s,
    fill="tozeroy",
    fillcolor="rgba(139,92,246,0.12)",
    line=dict(color=COLORS["accent"], width=2.5),
    name=f"PR Curve (AP={viz['ap']:.3f})",
    mode="lines",
))
# Baseline
fig7.add_hline(
    y=df["isFraud"].mean(),
    line_dash="dot", line_color="#94a3b8",
    annotation_text=f"Baseline ({df['isFraud'].mean():.3f})",
    annotation_position="bottom right",
)
# Optimal threshold point
fig7.add_trace(go.Scatter(
    x=[opt_rec], y=[opt_prec],
    mode="markers+text",
    marker=dict(size=14, color=COLORS["fraud"],
                symbol="star", line=dict(width=1.5, color="white")),
    text=[f"  Optimal threshold<br>  thresh={opt_thresh:.3f}<br>  F1={opt_f1:.3f}"],
    textposition="top right",
    textfont=dict(color=COLORS["fraud"], size=12),
    name="Optimal Threshold",
    showlegend=True,
))

# Iso-F1 curves
for f1_target in [0.6, 0.75, 0.9]:
    r_range = np.linspace(0.01, 1, 200)
    p_iso   = f1_target * r_range / (2 * r_range - f1_target + 1e-9)
    p_iso   = np.clip(p_iso, 0, 1)
    valid   = (p_iso > 0) & (p_iso <= 1)
    fig7.add_trace(go.Scatter(
        x=r_range[valid], y=p_iso[valid],
        mode="lines",
        line=dict(color="#cbd5e1", width=1, dash="dot"),
        name=f"F1={f1_target}",
        showlegend=False,
    ))
    last_valid = np.where(valid)[0]
    if len(last_valid):
        ix = last_valid[len(last_valid)//2]
        fig7.add_annotation(
            x=r_range[ix], y=p_iso[ix],
            text=f"F1={f1_target}",
            showarrow=False, font=dict(size=10, color="#94a3b8"),
            xshift=10,
        )

fig7.update_layout(
    template="plotly_white", height=420,
    xaxis=dict(title="Recall", range=[0, 1]),
    yaxis=dict(title="Precision", range=[0, 1.05]),
    legend=dict(orientation="h", y=1.08),
    margin=dict(t=20, b=40),
)
st.plotly_chart(fig7, use_container_width=True)

# Threshold metrics table
c7, c8, c9, c10 = st.columns(4)
c7.metric("Optimal Threshold", f"{opt_thresh:.4f}")
c8.metric("Precision",         f"{opt_prec:.4f}")
c9.metric("Recall",            f"{opt_rec:.4f}")
c10.metric("F1-Score",         f"{opt_f1:.4f}")

# ════════════════════════════════════════════════════════════════════════════════
# BONUS — Interactive Scatter: TransactionAmt vs HourOfDay
# ════════════════════════════════════════════════════════════════════════════════
st.divider()
st.subheader("⭐ Bonus · Transaction Amount vs Hour of Day")
st.caption("Colored by fraud probability. Size proportional to amount. Hover for details.")

plot_df = fdf.sample(min(2000, len(fdf)), random_state=0).copy()

fig8 = px.scatter(
    plot_df,
    x="hour",
    y="TransactionAmt",
    color="risk_score",
    color_continuous_scale=[
        [0.0,  "#bbf7d0"],
        [0.35, "#fde68a"],
        [0.65, "#fca5a5"],
        [1.0,  "#ef4444"],
    ],
    size=np.sqrt(plot_df["TransactionAmt"]).clip(2, 20),
    size_max=18,
    hover_data={
        "TransactionID": True,
        "TransactionAmt": ":$,.2f",
        "risk_score": ":.4f",
        "P_emaildomain": True,
        "card4": True,
        "isFraud": True,
    },
    labels={
        "hour": "Hour of Day",
        "TransactionAmt": "Transaction Amount ($)",
        "risk_score": "Fraud Probability",
    },
    template="plotly_white",
    opacity=0.75,
)

# Mark confirmed fraud with X
fraud_plot = plot_df[plot_df["isFraud"] == 1]
fig8.add_trace(go.Scatter(
    x=fraud_plot["hour"],
    y=fraud_plot["TransactionAmt"],
    mode="markers",
    marker=dict(symbol="x-thin", size=10, color="rgba(0,0,0,0.5)",
                line=dict(width=2, color="rgba(0,0,0,0.5)")),
    name="Confirmed Fraud (✕)",
    hoverinfo="skip",
))

fig8.update_layout(
    height=500,
    coloraxis_colorbar=dict(
        title="Risk Score",
        tickvals=[0, 0.25, 0.5, 0.75, 1.0],
        ticktext=["0 (safe)", "0.25", "0.5", "0.75", "1.0 (fraud)"],
        thickness=14, len=0.85,
    ),
    xaxis=dict(tickvals=list(range(0, 24, 2)), title="Hour of Day"),
    yaxis=dict(title="Transaction Amount ($)", type="log"),
    legend=dict(orientation="h", y=-0.12),
    margin=dict(t=20, b=60),
)
st.plotly_chart(fig8, use_container_width=True)

st.info(
    "💡 **Reading the scatter**: dots ✕-marked are confirmed fraud cases. "
    "Red/orange dots = high model risk score. Use sidebar to filter by product or device. "
    "Log scale on y-axis to show the full amount range.",
    icon="💡"
)
