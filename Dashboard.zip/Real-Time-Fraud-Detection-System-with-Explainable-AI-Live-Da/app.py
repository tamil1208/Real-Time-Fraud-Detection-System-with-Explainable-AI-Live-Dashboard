"""
app.py — FraudOps Dashboard
Run: streamlit run app.py
"""

import os
import base64
import streamlit as st

st.set_page_config(
    page_title="FraudOps — Real-time Risk Intelligence",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Background image ──────────────────────────────────────────────────────────
def _inject_bg():
    _img_path = os.path.join(os.path.dirname(__file__), "static", "bg.png")
    if os.path.exists(_img_path):
        with open(_img_path, "rb") as _f:
            _b64 = base64.b64encode(_f.read()).decode()
        st.markdown(
            f"""
            <style>
            /* Full-app background */
            .stApp {{
                background-image: url("data:image/png;base64,{_b64}");
                background-size: cover;
                background-position: center;
                background-attachment: fixed;
                background-repeat: no-repeat;
            }}
            /* Dark semi-transparent overlay so content stays readable */
            .stApp::before {{
                content: "";
                position: fixed;
                inset: 0;
                background: rgba(10, 20, 50, 0.72);
                z-index: 0;
                pointer-events: none;
            }}
            /* Lift all content above the overlay */
            .stApp > * {{
                position: relative;
                z-index: 1;
            }}
            /* Make sidebar semi-transparent dark glass */
            [data-testid="stSidebar"] {{
                background: rgba(10, 18, 45, 0.85) !important;
                backdrop-filter: blur(8px);
            }}
            /* Lighten all text so it reads on dark bg */
            html, body, [class*="css"] {{
                color: #e2e8f0;
            }}
            [data-testid="stMetricLabel"] {{
                color: #94a3b8 !important;
            }}
            [data-testid="stMetricValue"] {{
                color: #f1f5f9 !important;
            }}
            /* KPI cards background */
            [data-testid="metric-container"] {{
                background: rgba(255,255,255,0.07);
                border-radius: 10px;
                padding: 0.6rem 1rem;
                border: 1px solid rgba(255,255,255,0.1);
            }}
            /* Content blocks */
            .block-container {{
                background: rgba(10, 18, 45, 0.55);
                border-radius: 12px;
                padding: 2rem 2.5rem !important;
                backdrop-filter: blur(6px);
            }}
            </style>
            """,
            unsafe_allow_html=True,
        )

_inject_bg()

# ── First-run guard: generate precomputed data if missing ─────────────────────
_viz_path = os.path.join(os.path.dirname(__file__), ".cache", "viz_data.json")
if not os.path.exists(_viz_path):
    with st.spinner("First-run setup: computing SHAP & model metrics (30–60 s)…"):
        import subprocess, sys
        subprocess.run([sys.executable, "precompute.py"], check=True)
        st.rerun()

# ── Sidebar global brand ──────────────────────────────────────────────────────
st.sidebar.markdown(
    """
    <div style='text-align:center; padding: 1.2rem 0 0.8rem 0;'>
        <span style='font-size:2.4rem'>🛡️</span><br>
        <span style='font-weight:800; font-size:1.2rem; letter-spacing:0.03em'>FraudOps</span><br>
        <span style='font-size:0.72rem; color:#94a3b8; letter-spacing:0.05em'>REAL-TIME RISK INTELLIGENCE</span>
    </div>
    <hr style='margin:0.6rem 0; border-color:#e2e8f0'>
    """,
    unsafe_allow_html=True,
)

pg = st.navigation([
    st.Page("pages/01_Overview.py",             title="Overview",              icon="📊"),
    st.Page("pages/02_Transaction_Explorer.py", title="Transaction Explorer",  icon="🔍"),
    st.Page("pages/03_SHAP_Explainer.py",       title="SHAP Explainer",        icon="🧠"),
    st.Page("pages/04_Visualizations.py",       title="Visualizations",        icon="📈"),
])
pg.run()
