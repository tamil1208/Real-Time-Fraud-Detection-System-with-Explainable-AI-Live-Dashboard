"""
Page 2 — Transaction Explorer
Searchable / filterable table + live risk score lookup.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from data_utils import load_data, load_model, load_encoders, prepare_row, FEATURES

@st.cache_data(show_spinner="Loading transactions…")
def get_data():
    return load_data()

@st.cache_resource(show_spinner="Loading model…")
def get_model():
    return load_model()

@st.cache_resource(show_spinner="Loading encoders…")
def get_encoders():
    return load_encoders()

df       = get_data()
model    = get_model()
encoders = get_encoders()

# ── Sidebar filters ───────────────────────────────────────────────────────────
st.sidebar.header("🎛️ Filters")

products = st.sidebar.multiselect(
    "Product Code", options=sorted(df["ProductCD"].unique()),
    default=sorted(df["ProductCD"].unique()), key="exp_prod"
)
fraud_filter = st.sidebar.radio(
    "Transaction Type", ["All", "Fraud Only", "Legitimate Only"]
)
risk_thresh = st.sidebar.slider(
    "Min Risk Score", 0.0, 1.0, 0.0, 0.01
)
amt_range = st.sidebar.slider(
    "Amount Range ($)", float(df["TransactionAmt"].min()),
    float(df["TransactionAmt"].max()),
    (float(df["TransactionAmt"].min()), float(df["TransactionAmt"].max())),
    step=10.0, key="exp_amt"
)

# ── Apply filters ─────────────────────────────────────────────────────────────
fdf = df[
    df["ProductCD"].isin(products) &
    df["TransactionAmt"].between(*amt_range) &
    (df["risk_score"] >= risk_thresh)
].copy()

if fraud_filter == "Fraud Only":
    fdf = fdf[fdf["isFraud"] == 1]
elif fraud_filter == "Legitimate Only":
    fdf = fdf[fdf["isFraud"] == 0]

# ── Page header ───────────────────────────────────────────────────────────────
st.title("🔍 Transaction Explorer")

# ── Search bar ────────────────────────────────────────────────────────────────
search_q = st.text_input(
    "🔎 Search by Transaction ID or Email Domain",
    placeholder="e.g. T100042 or gmail.com"
)
if search_q.strip():
    q = search_q.strip().lower()
    fdf = fdf[
        fdf["TransactionID"].str.lower().str.contains(q) |
        fdf["P_emaildomain"].str.lower().str.contains(q)
    ]

st.caption(f"**{len(fdf):,}** transactions match your filters")

# ── Display table ─────────────────────────────────────────────────────────────
display_cols = ["TransactionID", "TransactionAmt", "ProductCD",
                "card4", "P_emaildomain", "DeviceType",
                "addr1", "dist1", "hour", "risk_score", "isFraud"]

def style_risk(val):
    if val >= 0.7:
        return "background-color:#fecaca; color:#7f1d1d; font-weight:600"
    elif val >= 0.4:
        return "background-color:#fde68a; color:#78350f"
    return "background-color:#bbf7d0; color:#14532d"

def style_fraud(val):
    if val == 1:
        return "background-color:#fecaca; color:#7f1d1d; font-weight:700"
    return ""

styled = (
    fdf[display_cols]
      .head(500)
      .style
      .applymap(style_risk, subset=["risk_score"])
      .applymap(style_fraud, subset=["isFraud"])
      .format({"TransactionAmt": "${:,.2f}", "risk_score": "{:.4f}"})
)

st.dataframe(styled, use_container_width=True, height=420)

st.info("⬆️ Showing up to 500 rows. Use filters to narrow down.", icon="ℹ️")

# ── Live Risk Score Lookup ────────────────────────────────────────────────────
st.divider()
st.subheader("⚡ Live Risk Score by Transaction ID")

tid = st.text_input("Enter Transaction ID", placeholder="e.g. T100042")

if tid.strip():
    row_matches = df[df["TransactionID"] == tid.strip()]
    if row_matches.empty:
        st.error(f"Transaction **{tid}** not found.")
    else:
        row = row_matches.iloc[0]
        X_row = prepare_row(row, encoders)
        score = model.predict_proba(X_row)[0, 1]

        risk_color = "#ef4444" if score >= 0.7 else "#f59e0b" if score >= 0.4 else "#22c55e"
        risk_label = "🔴 HIGH RISK" if score >= 0.7 else "🟡 MEDIUM RISK" if score >= 0.4 else "🟢 LOW RISK"

        r1, r2, r3 = st.columns([1, 1, 1])
        r1.metric("Risk Score", f"{score:.4f}")
        r2.metric("Risk Level", risk_label)
        r3.metric("Amount", f"${row['TransactionAmt']:,.2f}")

        # Gauge chart
        fig = go.Figure(go.Indicator(
            mode="gauge+number",
            value=score * 100,
            number={"suffix": "%", "font": {"size": 36}},
            title={"text": f"Fraud Risk — {tid}", "font": {"size": 16}},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"color": risk_color},
                "steps": [
                    {"range": [0, 40],  "color": "#bbf7d0"},
                    {"range": [40, 70], "color": "#fde68a"},
                    {"range": [70, 100],"color": "#fecaca"},
                ],
                "threshold": {
                    "line": {"color": "black", "width": 3},
                    "thickness": 0.8,
                    "value": score * 100
                }
            }
        ))
        fig.update_layout(height=300, margin=dict(t=50, b=20, l=30, r=30),
                          template="plotly_white")
        st.plotly_chart(fig, use_container_width=True)

        with st.expander("📋 Full Transaction Details"):
            detail_df = row[["TransactionID", "TransactionAmt", "ProductCD",
                              "card4", "P_emaildomain", "DeviceType",
                              "addr1", "dist1", "hour", "day_of_week", "isFraud"]].to_frame("Value")
            st.dataframe(detail_df, use_container_width=True)
