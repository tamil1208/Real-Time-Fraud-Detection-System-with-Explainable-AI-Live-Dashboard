"""
app.py — Fraud Operations Dashboard
Run: streamlit run app.py
"""

import streamlit as st

st.set_page_config(
    page_title="Fraud Operations Dashboard",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Sidebar global brand ──────────────────────────────────────────────────────
st.sidebar.markdown(
    """
    <div style='text-align:center; padding: 1rem 0 0.5rem 0;'>
        <span style='font-size:2rem'>🛡️</span><br>
        <span style='font-weight:700; font-size:1.1rem'>FraudOps</span><br>
        <span style='font-size:0.75rem; color:#888'>Real-time Risk Intelligence</span>
    </div>
    <hr style='margin:0.5rem 0'>
    """,
    unsafe_allow_html=True,
)

pg = st.navigation([
    st.Page("pages/01_Overview.py",            title="Overview",             icon="📊"),
    st.Page("pages/02_Transaction_Explorer.py", title="Transaction Explorer", icon="🔍"),
    st.Page("pages/03_SHAP_Explainer.py",      title="SHAP Explainer",       icon="🧠"),
    st.Page("pages/04_Visualizations.py",      title="Visualizations",       icon="📈"),
])
pg.run()
