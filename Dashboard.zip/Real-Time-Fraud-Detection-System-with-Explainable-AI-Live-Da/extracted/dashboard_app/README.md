# 🛡️ Fraud Operations Dashboard

A multi-page Streamlit application for fraud detection analytics, risk scoring, and ML explainability.

## 🚀 Deploy to Streamlit Community Cloud (Free)

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io) → **New app**
3. Set **Main file path**: `app.py`
4. Click **Deploy** — your live URL will appear!

## Pages

| Page | Description |
|------|-------------|
| 📊 **Overview** | KPI cards + interactive Plotly charts |
| 🔍 **Transaction Explorer** | Searchable table with live risk score gauge |
| 🧠 **SHAP Explainer** | Waterfall plot + plain-English explanation |
| 📈 **Visualizations** | Advanced charts and analytics |

## Local Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```
