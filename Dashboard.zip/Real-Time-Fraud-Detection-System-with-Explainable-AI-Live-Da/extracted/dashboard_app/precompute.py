"""
precompute.py — run once before starting the app (or on Streamlit Cloud via startup command).
Generates: .cache/transactions.parquet, .cache/model.pkl, .cache/encoders.pkl, .cache/viz_data.json
"""
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from data_utils import load_data, load_model, load_encoders, FEATURES
import shap
from sklearn.metrics import precision_recall_curve, average_precision_score

print("Loading / generating data…")
df = load_data()
model = load_model()
encoders = load_encoders()

print(f"Dataset ready: {len(df):,} rows, fraud rate {df.isFraud.mean():.2%}")

# Build encoded matrix for SHAP
df2 = df.copy()
cat_cols = ["ProductCD", "card4", "P_emaildomain", "DeviceType"]
for col in cat_cols:
    le = encoders[col]
    df2[f"{col}_enc"] = df2[col].astype(str).map(
        lambda x, le=le: le.transform([x])[0] if x in le.classes_ else -1
    )
X_all = df2[FEATURES].values
y_all = df2["isFraud"].values

# SHAP (500 sample)
print("Computing SHAP values…")
rng = np.random.default_rng(42)
idx = rng.choice(len(X_all), 500, replace=False)
explainer = shap.TreeExplainer(model)
sv = explainer.shap_values(X_all[idx])
if isinstance(sv, list):
    sv = sv[1]
sv = np.array(sv)
mean_abs = np.abs(sv).mean(axis=0)

feat_labels = [
    "Transaction Amount", "Product Category", "Card Network",
    "Billing Area", "Distance (km)", "Email Domain",
    "Device Type", "Hour of Day", "Day of Week",
]

# PR curve
print("Computing Precision-Recall curve…")
probs = model.predict_proba(X_all)[:, 1]
prec, rec, threshs = precision_recall_curve(y_all, probs)
ap = average_precision_score(y_all, probs)
f1s = 2 * prec[:-1] * rec[:-1] / (prec[:-1] + rec[:-1] + 1e-9)
opt_idx = int(np.argmax(f1s))

step = max(1, len(prec) // 300)

cache_dir = os.path.join(os.path.dirname(__file__), ".cache")
os.makedirs(cache_dir, exist_ok=True)

data = {
    "mean_abs"    : mean_abs.tolist(),
    "feat_labels" : feat_labels,
    "shap_vals"   : sv.tolist(),
    "shap_features": X_all[idx].tolist(),
    "y_sample"    : y_all[idx].tolist(),
    "prec"        : prec[::step].tolist(),
    "rec"         : rec[::step].tolist(),
    "threshs"     : threshs[::step].tolist(),
    "ap"          : float(ap),
    "opt_thresh"  : float(threshs[opt_idx]),
    "opt_f1"      : float(f1s[opt_idx]),
    "opt_prec"    : float(prec[opt_idx]),
    "opt_rec"     : float(rec[opt_idx]),
    "probs_all"   : probs.tolist(),
}

out = os.path.join(cache_dir, "viz_data.json")
with open(out, "w") as f:
    json.dump(data, f)

print(f"Saved {out}  ({os.path.getsize(out)//1024} KB)")
print("Pre-compute complete ✓")
