"""
data_utils.py — synthetic fraud dataset + trained model cache.
Swap generate_data() for pd.read_csv("your_data.csv") to use real data.
Expected columns: TransactionID, TransactionAmt, ProductCD, card4,
                  addr1, dist1, P_emaildomain, DeviceType, isFraud
"""

import numpy as np
import pandas as pd
import pickle
import os
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.preprocessing import LabelEncoder

CACHE_DIR = os.path.join(os.path.dirname(__file__), ".cache")
os.makedirs(CACHE_DIR, exist_ok=True)

DATA_PATH  = os.path.join(CACHE_DIR, "transactions.parquet")
MODEL_PATH = os.path.join(CACHE_DIR, "model.pkl")
ENC_PATH   = os.path.join(CACHE_DIR, "encoders.pkl")

FEATURES = ["TransactionAmt", "ProductCD_enc", "card4_enc",
            "addr1", "dist1", "P_emaildomain_enc", "DeviceType_enc",
            "hour", "day_of_week"]

# ──────────────────────────────────────────────
# 1. Synthetic data generation
# ──────────────────────────────────────────────
def generate_data(n: int = 5_000, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)

    fraud_mask = rng.random(n) < 0.085          # ~8.5 % fraud rate

    product_codes = ["W", "H", "C", "S", "R"]
    card_types     = ["visa", "mastercard", "discover", "amex"]
    email_domains  = ["gmail.com", "yahoo.com", "hotmail.com",
                      "anonymous.com", "protonmail.com", "outlook.com"]
    device_types   = ["desktop", "mobile"]

    # Fraud transactions skew toward higher amounts & anonymous emails
    amounts = np.where(
        fraud_mask,
        rng.lognormal(mean=5.5, sigma=1.2, size=n),
        rng.lognormal(mean=4.2, sigma=1.1, size=n),
    ).round(2)

    p_email = np.where(
        fraud_mask,
        rng.choice(["anonymous.com", "protonmail.com"], size=n, p=[0.6, 0.4]),
        rng.choice(email_domains, size=n,
                   p=[0.35, 0.25, 0.20, 0.05, 0.08, 0.07]),
    )

    df = pd.DataFrame({
        "TransactionID"  : [f"T{100_000 + i}" for i in range(n)],
        "TransactionAmt" : amounts,
        "ProductCD"      : rng.choice(product_codes, size=n),
        "card4"          : rng.choice(card_types, size=n),
        "addr1"          : rng.integers(100, 500, size=n).astype(float),
        "dist1"          : np.where(fraud_mask,
                                    rng.exponential(50, n),
                                    rng.exponential(200, n)).round(1),
        "P_emaildomain"  : p_email,
        "DeviceType"     : rng.choice(device_types, size=n,
                                      p=[0.55, 0.45]),
        "hour"           : rng.integers(0, 24, size=n),
        "day_of_week"    : rng.integers(0, 7, size=n),
        "isFraud"        : fraud_mask.astype(int),
    })
    return df


# ──────────────────────────────────────────────
# 2. Encode + train
# ──────────────────────────────────────────────
def _encode(df: pd.DataFrame, encoders: dict | None = None):
    cat_cols = ["ProductCD", "card4", "P_emaildomain", "DeviceType"]
    if encoders is None:
        encoders = {}
        for col in cat_cols:
            le = LabelEncoder()
            df[f"{col}_enc"] = le.fit_transform(df[col].astype(str))
            encoders[col] = le
    else:
        for col in cat_cols:
            le = encoders[col]
            df[f"{col}_enc"] = df[col].astype(str).map(
                lambda x, le=le: le.transform([x])[0]
                if x in le.classes_ else -1
            )
    return df, encoders


def _train_model(df: pd.DataFrame, encoders: dict):
    X = df[FEATURES]
    y = df["isFraud"]
    model = GradientBoostingClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.08,
        subsample=0.8, random_state=42
    )
    model.fit(X, y)
    return model


# ──────────────────────────────────────────────
# 3. Public API
# ──────────────────────────────────────────────
def load_data() -> pd.DataFrame:
    if os.path.exists(DATA_PATH):
        return pd.read_parquet(DATA_PATH)
    df = generate_data()
    df_enc, encoders = _encode(df.copy())
    model = _train_model(df_enc, encoders)
    df["risk_score"] = model.predict_proba(df_enc[FEATURES])[:, 1].round(4)
    df.to_parquet(DATA_PATH, index=False)
    with open(MODEL_PATH, "wb") as f:
        pickle.dump(model, f)
    with open(ENC_PATH, "wb") as f:
        pickle.dump(encoders, f)
    return df


def load_model():
    if not os.path.exists(MODEL_PATH):
        load_data()
    with open(MODEL_PATH, "rb") as f:
        return pickle.load(f)


def load_encoders():
    if not os.path.exists(ENC_PATH):
        load_data()
    with open(ENC_PATH, "rb") as f:
        return pickle.load(f)


def prepare_row(row: pd.Series, encoders: dict) -> pd.DataFrame:
    """Encode a single row for model inference."""
    r = row.copy().to_frame().T
    cat_cols = ["ProductCD", "card4", "P_emaildomain", "DeviceType"]
    for col in cat_cols:
        le = encoders[col]
        val = str(r[col].iloc[0])
        r[f"{col}_enc"] = le.transform([val])[0] if val in le.classes_ else -1
    return r[FEATURES]
