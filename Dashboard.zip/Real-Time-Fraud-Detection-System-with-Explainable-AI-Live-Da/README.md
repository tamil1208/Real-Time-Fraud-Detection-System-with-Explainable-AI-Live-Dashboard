# 🛡️ FraudOps — Real-time Fraud Detection Dashboard

A production-quality, multi-page **Streamlit** application for fraud detection analytics, ML-powered risk scoring, and Explainable AI (XAI) — built for fraud operations teams.

## 🔗 Live Demo

> Deploy on [Replit](https://replit.com) or [Streamlit Community Cloud](https://share.streamlit.io).  
> **Live URL:** *(add your deployed URL here after publishing)*

---

## 📊 Pages & Features

| Page | Features |
|------|----------|
| 📊 **Overview** | KPI cards (total transactions, fraud count, detection rate, avg fraud amount) + 5 interactive Plotly charts with sidebar filters |
| 🔍 **Transaction Explorer** | Full-text search, multi-filter table (500 rows), live risk-score gauge with model inference |
| 🧠 **SHAP Explainer** | Enter any Transaction ID → SHAP waterfall plot + plain-English explanation of each feature's contribution |
| 📈 **Visualizations** | SHAP Global Summary, Fraud Rate by Hour, Amount Distribution, Risk Tier Donut, Precision-Recall Curve + bonus interactive scatter |

---

## 🛠️ Tech Stack

| Component | Technology |
|-----------|-----------|
| App framework | Streamlit 1.35+ |
| ML model | Gradient Boosting Classifier (scikit-learn) |
| Explainability | SHAP (TreeExplainer) |
| Visualizations | Plotly Express & Graph Objects |
| Data | Synthetic fraud dataset (5,000 transactions, ~8.2% fraud rate) |

---

## 🚀 Local Setup

```bash
# 1. Clone the repository
git clone <repo-url>
cd <repo-dir>

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the app
streamlit run app.py
```

The app auto-generates all data, model, and SHAP cache files on first run.

---

## ☁️ Deploy to Streamlit Community Cloud (Free)

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io) → **New app**
3. Select your repo, set **Main file path**: `app.py`
4. Click **Deploy** — your live URL will appear in seconds!

---

## 📁 Project Structure

```
├── app.py                    # Main entry point + navigation
├── precompute.py             # One-time SHAP & metric pre-computation
├── data_utils.py             # Data generation, model training, utilities
├── requirements.txt          # Python dependencies
├── pages/
│   ├── 01_Overview.py        # KPI dashboard
│   ├── 02_Transaction_Explorer.py  # Searchable transaction table
│   ├── 03_SHAP_Explainer.py  # Per-transaction XAI
│   └── 04_Visualizations.py  # Advanced ML charts
└── .cache/                   # Auto-generated (model, data, SHAP values)
    ├── transactions.parquet
    ├── model.pkl
    ├── encoders.pkl
    └── viz_data.json
```
