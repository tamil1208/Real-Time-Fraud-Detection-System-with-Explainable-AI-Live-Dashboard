"""
Page 1 — Overview
KPI cards + interactive Plotly charts with sidebar filters.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from data_utils import load_data

@st.cache_data(show_spinner="Loading transactions…")
def get_data():
    return load_data()

df = get_data()

# ── Sidebar filters ───────────────────────────────────────────────────────────
st.sidebar.header("🎛️ Filters")

products = st.sidebar.multiselect(
    "Product Code", options=sorted(df["ProductCD"].unique()),
    default=sorted(df["ProductCD"].unique())
)
cards = st.sidebar.multiselect(
    "Card Type", options=sorted(df["card4"].unique()),
    default=sorted(df["card4"].unique())
)
devices = st.sidebar.multiselect(
    "Device Type", options=sorted(df["DeviceType"].unique()),
    default=sorted(df["DeviceType"].unique())
)

_step       = 10.0
_slider_min = (df["TransactionAmt"].min() // _step) * _step
_slider_max = ((df["TransactionAmt"].max() // _step) + 1) * _step

amt_range = st.sidebar.slider(
    "Transaction Amount ($)",
    float(_slider_min), float(_slider_max),
    (float(_slider_min), float(_slider_max)),
    step=_step,
)

mask = (
    df["ProductCD"].isin(products) &
    df["card4"].isin(cards) &
    df["DeviceType"].isin(devices) &
    df["TransactionAmt"].between(*amt_range)
)
fdf = df[mask]

# ── Page header ───────────────────────────────────────────────────────────────
st.title("📊 Overview")
st.caption(f"Showing **{len(fdf):,}** of {len(df):,} transactions after filters")

# ── KPI cards ─────────────────────────────────────────────────────────────────
total_txns    = len(fdf)
total_fraud   = fdf["isFraud"].sum()
det_rate      = total_fraud / total_txns * 100 if total_txns else 0
avg_fraud_amt = fdf.loc[fdf["isFraud"] == 1, "TransactionAmt"].mean() if total_fraud else 0

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Transactions",  f"{total_txns:,}")
k2.metric("Total Fraud Cases",   f"{int(total_fraud):,}",
          delta=f"{det_rate:.2f}% of total", delta_color="inverse")
k3.metric("Detection Rate",      f"{det_rate:.2f}%")
k4.metric("Avg Fraud Amount",    f"${avg_fraud_amt:,.2f}")

st.divider()

# ── Charts ────────────────────────────────────────────────────────────────────
col1, col2 = st.columns(2)

with col1:
    st.subheader("Fraud vs Legitimate by Product")
    prod_cnt = (
        fdf.groupby(["ProductCD", "isFraud"])
           .size().reset_index(name="count")
    )
    fig = go.Figure()
    for fraud_val, label, color in [(0, "Legitimate", "#3b82f6"), (1, "Fraud", "#ef4444")]:
        d = prod_cnt[prod_cnt["isFraud"] == fraud_val]
        fig.add_trace(go.Bar(x=d["ProductCD"], y=d["count"], name=label, marker_color=color))
    fig.update_layout(barmode="group", template="plotly_white", height=350,
                      legend_title_text="", xaxis_title="Product", yaxis_title="Count")
    st.plotly_chart(fig, width="stretch")

with col2:
    st.subheader("Transaction Amount Distribution")
    fig2 = go.Figure()
    for fraud_val, label, color in [(0, "Legitimate", "#3b82f6"), (1, "Fraud", "#ef4444")]:
        vals = fdf.loc[fdf["isFraud"] == fraud_val, "TransactionAmt"]
        fig2.add_trace(go.Histogram(x=vals, name=label, nbinsx=60,
                                    marker_color=color, opacity=0.7))
    fig2.update_layout(barmode="overlay", template="plotly_white", height=350,
                       xaxis_title="Amount ($)", yaxis_title="Count", legend_title_text="")
    st.plotly_chart(fig2, width="stretch")

col3, col4 = st.columns(2)

with col3:
    st.subheader("Fraud by Hour of Day")
    hourly = (
        fdf[fdf["isFraud"] == 1]
           .groupby("hour").size().reset_index(name="fraud_count")
    )
    fig3 = go.Figure(go.Scatter(
        x=hourly["hour"], y=hourly["fraud_count"],
        mode="lines", fill="tozeroy",
        line=dict(color="#ef4444", width=2),
        fillcolor="rgba(239,68,68,0.15)"
    ))
    fig3.update_layout(template="plotly_white", height=300,
                       xaxis_title="Hour", yaxis_title="Fraud Count")
    st.plotly_chart(fig3, width="stretch")

with col4:
    st.subheader("Risk Score Distribution")
    fig4 = go.Figure()
    fig4.add_trace(go.Violin(
        y=fdf.loc[fdf["isFraud"] == 0, "risk_score"],
        name="Legitimate", side="negative",
        line_color="#3b82f6", fillcolor="#bfdbfe", opacity=0.7
    ))
    fig4.add_trace(go.Violin(
        y=fdf.loc[fdf["isFraud"] == 1, "risk_score"],
        name="Fraud", side="positive",
        line_color="#ef4444", fillcolor="#fecaca", opacity=0.7
    ))
    fig4.update_layout(
        template="plotly_white", height=300,
        violingap=0, violinmode="overlay",
        yaxis_title="Risk Score"
    )
    st.plotly_chart(fig4, width="stretch")

# ── Fraud rate by card network ────────────────────────────────────────────────
st.subheader("Fraud Rate by Card Network")
card_stats = (
    fdf.groupby("card4")
       .agg(total=("isFraud", "count"), fraud=("isFraud", "sum"))
       .reset_index()
)
card_stats["fraud_rate"] = (card_stats["fraud"] / card_stats["total"] * 100).round(2)
card_stats = card_stats.sort_values("fraud_rate", ascending=False)

fig5 = go.Figure(go.Bar(
    x=card_stats["card4"],
    y=card_stats["fraud_rate"],
    text=[f"{v:.2f}%" for v in card_stats["fraud_rate"]],
    textposition="outside",
    marker=dict(
        color=card_stats["fraud_rate"],
        colorscale=[[0,"#bbf7d0"],[0.33,"#fde68a"],[0.66,"#fca5a5"],[1,"#ef4444"]],
        showscale=False,
    ),
))
fig5.update_layout(template="plotly_white", height=320,
                   xaxis_title="Card Network", yaxis_title="Fraud Rate (%)")
st.plotly_chart(fig5, width="stretch")
