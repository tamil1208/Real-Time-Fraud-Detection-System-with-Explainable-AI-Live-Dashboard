"""
Page 3 — SHAP Explainer
Waterfall plot + plain-English explanation for any TransactionID.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import shap
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from data_utils import load_data, load_model, load_encoders, prepare_row, FEATURES

@st.cache_data(show_spinner="Loading transactions…")
def get_data():
    return load_data()

@st.cache_resource(show_spinner="Loading model…")
def get_model():
    return load_model()

@st.cache_resource(show_spinner="Loading encoders…")
def get_encoders():
    return load_encoders()

@st.cache_resource(show_spinner="Initialising SHAP explainer (first time only)…")
def get_explainer(_model, background):
    return shap.TreeExplainer(_model, data=background, feature_perturbation="interventional")

df       = get_data()
model    = get_model()
encoders = get_encoders()

# Build a background sample for the explainer (encoded)
@st.cache_data(show_spinner=False)
def get_background():
    enc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)),
                            ".cache", "encoders.pkl")
    import pickle
    with open(enc_path, "rb") as f:
        enc = pickle.load(f)
    sample = df.sample(200, random_state=0).copy()
    cat_cols = ["ProductCD", "card4", "P_emaildomain", "DeviceType"]
    for col in cat_cols:
        le = enc[col]
        sample[f"{col}_enc"] = sample[col].astype(str).map(
            lambda x, le=le: le.transform([x])[0] if x in le.classes_ else -1
        )
    return sample[FEATURES].values

background = get_background()
explainer  = get_explainer(model, background)

# ── Feature display name mapping ─────────────────────────────────────────────
FEAT_LABELS = {
    "TransactionAmt"   : "Transaction Amount",
    "ProductCD_enc"    : "Product Category",
    "card4_enc"        : "Card Network",
    "addr1"            : "Billing ZIP Area",
    "dist1"            : "Distance (km)",
    "P_emaildomain_enc": "Payer Email Domain",
    "DeviceType_enc"   : "Device Type",
    "hour"             : "Hour of Day",
    "day_of_week"      : "Day of Week",
}

# ── Plain-English templates ───────────────────────────────────────────────────
def plain_english(feature, shap_val, feature_val, row, encoders):
    direction = "increases" if shap_val > 0 else "decreases"
    strength  = abs(shap_val)
    impact    = "strongly" if strength > 0.1 else ("moderately" if strength > 0.04 else "slightly")

    if feature == "TransactionAmt":
        return (f"**Transaction Amount** (${feature_val:,.2f}) {impact} {direction} the risk. "
                f"{'Higher amounts are more suspicious.' if shap_val > 0 else 'This is a typical transaction size.'}")
    if feature == "P_emaildomain_enc":
        domain = row.get("P_emaildomain", "unknown")
        suspicious = domain in ["anonymous.com", "protonmail.com"]
        note = "Anonymous/private domains are strongly associated with fraud." if suspicious else "This is a common, trusted email domain."
        return f"**Email Domain** (`{domain}`) {impact} {direction} the risk. {note}"
    if feature == "dist1":
        return (f"**Transaction Distance** ({feature_val:.1f} km) {impact} {direction} the risk. "
                f"{'Short distances are typical for genuine users.' if shap_val < 0 else 'Unusually large distances can indicate account takeover.'}")
    if feature == "hour":
        h = int(feature_val)
        tod = "late night/early morning" if h < 6 or h > 22 else "daytime"
        return (f"**Hour of Day** ({h:02d}:00) {impact} {direction} the risk. "
                f"Transactions at {tod} hours {'are sometimes flagged' if shap_val > 0 else 'are common'}.")
    if feature == "card4_enc":
        try:
            card = encoders["card4"].inverse_transform([int(feature_val)])[0]
        except Exception:
            card = "unknown"
        return (f"**Card Network** ({card}) {impact} {direction} the risk. "
                f"Some card networks have higher fraud prevalence in this dataset.")
    if feature == "DeviceType_enc":
        try:
            dev = encoders["DeviceType"].inverse_transform([int(feature_val)])[0]
        except Exception:
            dev = "unknown"
        return (f"**Device Type** ({dev}) {impact} {direction} the risk.")
    if feature == "addr1":
        return f"**Billing Area** (code {int(feature_val)}) {impact} {direction} the risk."
    if feature == "day_of_week":
        days = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"]
        d = days[int(feature_val) % 7]
        return f"**Day of Week** ({d}) {impact} {direction} the risk."
    if feature == "ProductCD_enc":
        try:
            prod = encoders["ProductCD"].inverse_transform([int(feature_val)])[0]
        except Exception:
            prod = "unknown"
        return f"**Product Category** ({prod}) {impact} {direction} the risk."
    return f"**{FEAT_LABELS.get(feature, feature)}** {impact} {direction} the risk."

# ── Waterfall chart ───────────────────────────────────────────────────────────
def waterfall_plotly(shap_vals, feature_vals, base_value, pred_value, labels):
    order    = np.argsort(np.abs(shap_vals))[::-1][:8]
    sv_ord   = shap_vals[order]
    fv_ord   = feature_vals[order]
    lab_ord  = [labels[i] for i in order]

    fig = go.Figure(go.Waterfall(
        orientation="h",
        measure=["relative"] * len(sv_ord) + ["total"],
        x=list(sv_ord) + [pred_value],
        y=lab_ord + ["🎯 Final Score"],
        base=base_value,
        connector={"mode": "between", "line": {"width": 1, "color": "#94a3b8", "dash": "dot"}},
        decreasing={"marker": {"color": "#3b82f6"}},
        increasing={"marker": {"color": "#ef4444"}},
        totals={"marker": {"color": "#8b5cf6"}},
        text=[f"{v:+.4f}" for v in sv_ord] + [f"{pred_value:.4f}"],
        textposition="outside",
    ))

    fig.add_vline(x=base_value, line_dash="dash", line_color="#64748b",
                  annotation_text=f"Base: {base_value:.3f}", annotation_position="top right")

    fig.update_layout(
        title="SHAP Waterfall — Feature Contributions to Fraud Risk",
        xaxis_title="Model Output (Fraud Probability)",
        template="plotly_white",
        height=420,
        margin=dict(l=180, r=60, t=60, b=40),
        showlegend=False,
    )
    return fig

# ══════════════════════════════════════════════════════════════════════════════
# PAGE
# ══════════════════════════════════════════════════════════════════════════════
st.title("🧠 SHAP Explainer")
st.markdown(
    "Enter a **Transaction ID** to understand *why* the model flagged (or cleared) it. "
    "SHAP values show each feature's contribution to the final risk score."
)

tid = st.text_input("Transaction ID", placeholder="e.g. T100042")

if not tid.strip():
    col_btn, _ = st.columns([1, 3])
    with col_btn:
        if st.button("🎲 Pick a random HIGH-RISK transaction", use_container_width=True):
            high_risk = df[df["risk_score"] >= 0.7]
            if not high_risk.empty:
                st.session_state["shap_tid"] = high_risk.sample(1).iloc[0]["TransactionID"]
                st.rerun()
    if "shap_tid" in st.session_state:
        tid = st.session_state["shap_tid"]

if tid.strip():
    row_matches = df[df["TransactionID"] == tid.strip()]
    if row_matches.empty:
        st.error(f"Transaction **{tid}** not found. Please check the ID.")
        st.stop()

    row      = row_matches.iloc[0]
    X_row    = prepare_row(row, encoders)
    score    = model.predict_proba(X_row)[0, 1]
    sv       = explainer.shap_values(X_row)
    if isinstance(sv, list):
        sv = sv[1]
    sv = np.array(sv).flatten()
    base_val = float(explainer.expected_value[1] if isinstance(explainer.expected_value, np.ndarray)
                     else explainer.expected_value)

    feature_vals = X_row.values.flatten()

    # ── Risk banner ───────────────────────────────────────────────────────────
    risk_col = "#ef4444" if score >= 0.7 else "#f59e0b" if score >= 0.4 else "#22c55e"
    risk_lbl = "HIGH RISK 🔴" if score >= 0.7 else "MEDIUM RISK 🟡" if score >= 0.4 else "LOW RISK 🟢"
    st.markdown(
        f"""<div style='background:{risk_col}22; border-left:5px solid {risk_col};
        padding:0.8rem 1.2rem; border-radius:6px; margin-bottom:1rem'>
        <b style='font-size:1.1rem; color:{risk_col}'>{risk_lbl}</b> &nbsp;|&nbsp;
        Transaction <b>{tid}</b> &nbsp;|&nbsp;
        Risk Score: <b>{score:.4f}</b> &nbsp;|&nbsp;
        Amount: <b>${row['TransactionAmt']:,.2f}</b>
        </div>""",
        unsafe_allow_html=True
    )

    # ── Waterfall plot ────────────────────────────────────────────────────────
    labels = [FEAT_LABELS.get(f, f) for f in FEATURES]
    fig    = waterfall_plotly(sv, feature_vals, base_val, score, labels)
    st.plotly_chart(fig, width="stretch")

    # ── Plain-English Explanation ─────────────────────────────────────────────
    st.subheader("📖 Plain-English Explanation")

    order = np.argsort(np.abs(sv))[::-1][:6]
    explanations = []
    for idx in order:
        feat = FEATURES[idx]
        fval = feature_vals[idx]
        sval = sv[idx]
        if abs(sval) < 0.005:
            continue
        explanations.append((sval, plain_english(feat, sval, fval, row.to_dict(), encoders)))

    if score >= 0.5:
        intro = (f"This transaction was flagged as **likely fraudulent** "
                 f"(risk score {score:.2%}). Here's why:")
    else:
        intro = (f"This transaction appears **likely legitimate** "
                 f"(risk score {score:.2%}). Key reasons:")
    st.markdown(intro)

    for sval, text in explanations:
        icon = "🔺" if sval > 0 else "🔻"
        st.markdown(f"- {icon} {text}")

    # ── Feature contribution bar chart ───────────────────────────────────────
    st.subheader("📊 Feature Contribution Summary")
    bar_df = pd.DataFrame({
        "Feature"     : [FEAT_LABELS.get(f, f) for f in FEATURES],
        "SHAP Value"  : sv,
        "Direction"   : ["Increases Risk ↑" if v > 0 else "Decreases Risk ↓" for v in sv]
    }).sort_values("SHAP Value", key=abs, ascending=False).head(8)

    fig2 = go.Figure(go.Bar(
        x=bar_df["SHAP Value"],
        y=bar_df["Feature"],
        orientation="h",
        marker_color=["#ef4444" if v > 0 else "#3b82f6" for v in bar_df["SHAP Value"]],
        text=[f"{v:+.4f}" for v in bar_df["SHAP Value"]],
        textposition="outside"
    ))
    fig2.update_layout(
        template="plotly_white", height=340,
        xaxis_title="SHAP Value (impact on risk score)",
        margin=dict(l=160, r=60, t=20, b=40)
    )
    fig2.add_vline(x=0, line_color="#94a3b8")
    st.plotly_chart(fig2, width="stretch")

    with st.expander("🔬 Raw SHAP values & encoded features"):
        debug_df = pd.DataFrame({
            "Feature"      : FEATURES,
            "Display Name" : [FEAT_LABELS.get(f, f) for f in FEATURES],
            "Encoded Value": feature_vals,
            "SHAP Value"   : sv,
        })
        st.dataframe(debug_df.style.format({"SHAP Value": "{:+.6f}",
                                             "Encoded Value": "{:.2f}"}),
                     width="stretch")
